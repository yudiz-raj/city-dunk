class InputManager {
    constructor(oScene) {
        this.oScene = oScene;
    }
}