class GameManager {
    constructor(oScene) {
        this.oScene = oScene;
    }
}